<?php
/*
 * return array( 'service_manager' => array( 'factories' => array(
 * 'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory', ), ),
 * 'db' => array( 'driver' => 'pdo', 'dsn' =>
 * 'mysql:dbname=CHANGEME;host=localhost', 'username' => 'CHANGEME', 'password'
 * => 'CHANGEME', ), );
 */

/*
		'service_manager' => array(
				'factories' => array(
						'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
				),
		),
		'db' => array(
				'driver'   => 'pdo',
				'dsn'      => 'sqlite:' . getcwd() . '/data/users.db',
		)
);*/
/*
return array(
		'doctrine' => array(
				'connection' => array(
						'orm_default' => array(
								'driverClass' => 'Doctrine\DBAL\Driver\PDOMySql\Driver',
								'params' => array(
										'host'     => 'localhost',
										'port'     => '3306',
										'user'     => 'root',
										'password' => 'noelia',
										'dbname'   => 'test'
								)
						)
				)
		),
);*/
return array (
		
		'doctrine' => array (
				'connection' => array (
						'orm_default' => array (
								'driverClass' => 'Doctrine\DBAL\Driver\PDOSqlite\Driver',
								'params' => array (
										'path' => '/home/tineo/makinap.com/public/ZendSkeletonApplication/data/apoyo.db' 
								) 
						) 
				) 
		) 
);
